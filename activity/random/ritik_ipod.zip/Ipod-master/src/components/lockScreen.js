import React from 'react';

function lockScreen() {
    return (
        <div className="lock-screen">Hello World
            <div className="background-img"></div>
            <div className="lock"></div>
            
        </div>
    )
}

export default lockScreen;
